# zkInfer evaluation manuscript draft

This package provides an editable evaluation section, figure/table layouts, and
an explicit mapping from the uploaded old paper to the new evaluation.

## Files

- `evaluation_draft.md`: readable manuscript copy, including the table contents
  and figure descriptions. LaTeX remains the authoritative typesetting source.
- `evaluation.tex`: complete section prose, experimental setup, tables and figure slots.
- `evaluation_preamble.tex`: small formatting helpers; load after booktabs/graphicx/xcolor.
- `legacy_results.tex`: old measurements transcribed from the supplied draft, clearly
  separated from current results. Included by default in the standalone wrapper.
- `legacy_granularity.tex`: the old partition/grouping table, ready for an appendix.
- `standalone.tex`: two-column wrapper for reviewing the section outside your paper.
- `figure_design.md`: exact visual encodings, panels, axes, aggregation and priorities.
- `legacy_mapping.md`: what to carry over, what to rerun, and inconsistencies to resolve.

## Include in your paper

Copy these files into the paper's working directory, add the packages below in
your preamble, then load the helper and section:

```latex
\usepackage{booktabs,graphicx,xcolor}
\input{evaluation_preamble}
% \includelegacyfalse % Hide the old-configuration table when replacing it.
...
\input{evaluation}
```

The section and figure numbers follow your document. The standalone wrapper sets
the section counter to 5 for preview as Section 6. Keep figures in `figures/evaluation/`.
Missing figure PDFs automatically produce labelled layout placeholders. There are
no invented result curves or sample measurements. Compile twice to resolve labels.

Local compilation could not be completed because this environment lacks
`pdflatex.fmt`. The source was checked for balanced braces/environments and
reference coverage, but final column widths and float placement require a compile
in your paper's TeX installation or Overleaf.

## Status conventions

- Blue `[PENDING: ...]` entries are facts or measured findings still needed.
- Gray draft notes are editorial instructions, not manuscript claims.
- Legacy results are real values reported in the uploaded old draft, not reruns
  of the present implementation. Preserve that distinction until configurations
  are reconciled. The current implementation has not been benchmarked by this draft.
- Methodology is written in manuscript present tense as the proposed protocol.
  Run it as specified, or revise it to match actual execution before submission.

## Setup facts that still require confirmation

The current characterization host is known: dual AMD EPYC 9354, 64 physical cores,
128 hardware threads, 755 GiB reported RAM. The old cloud setup is reported as
r6a.32xlarge (128 vCPUs, 1 TB RAM) and up to ten m6a.4xlarge workers (16 vCPUs,
64 GB RAM each), with the coordinator colocated on a worker. These are old-draft
descriptions, not confirmation of the next deployment or a GB/GiB conversion.

Still confirm: current cluster type/count; OS/kernel and backend/wheel versions;
prover thread settings; storage medium/network; exact verification timing boundary;
runtime-reported RAM on each cloud type; measured input/partition configuration.
The draft marks these rather than pretending the setup is fully measured.

## Section structure

Experimental Setup is followed by the five agreed subsections:

1. End-to-End Performance Under Concurrent Requests.
2. Contribution of Resource-Management Mechanisms (admission, scheduling, reuse).
3. Scaling Across Prover Nodes.
4. Impact of Partition Granularity (including the earlier decomposition results).
5. Operational Overheads and Robustness.

The last subsection contains proposed tests, not completed recovery claims.
Use only the overhead part if robustness is outside the implemented scope.

## Recommended main-paper budget

Core: three compact tables and four full-width figures (burst serving, sustained
serving, memory-budget sensitivity, scale-out). Add a compact partition-granularity
figure if it conveys information beyond the transferred table; otherwise place it
in the appendix. Scheduling and reuse have separate compact tables within the
mechanism subsection. Two additional table templates cover operational overhead
and robustness; retain only measured, relevant rows and move detail to the appendix.

The manuscript contains ready-to-use slots for these plus optional material.
For a short page budget, move sustained mixed-workload detail, the full fixed-k
sweep, legacy key-size/constraint tables, and grouping-policy detail to the appendix.
Keep the three individual-workload results visible even if a mixed workload helps.

## Before publication

Replace every pending entry; remove editorial notes; confirm every claim against
the corresponding raw runs; verify all completed requests/proof chains; and resolve
the old/current partition-count and hardware differences listed in legacy_mapping.md.
Do not combine old monolithic timing and new partitioned timing into a speedup.
