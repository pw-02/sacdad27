# Comparisons by experiment

Methods below are proposed, not completed runs. Use the same partitions, initial
artifacts, histories, thread settings, hardware and request sequence unless a row
explicitly varies that factor.

| Subsection / experiment | Configurations to run | Held fixed / varied |
|---|---|---|
| End-to-end: bursts | Selected Fixed-k, whole-job, zkInfer stage admission | Same coordinator; vary N=1,4,8,16. Warm primary, cold separately. |
| End-to-end: scheduled arrivals | Same three | Paired arrival schedules and identical absolute arrival rates. |
| Mechanisms: memory admission | Whole-job, stage | Same coordinator; budgets 64/128/256 GiB; cold and warm; N=16 primary. |
| Mechanisms: coordinator policy | FIFO, LPT, resource-aware | Stage admission throughout; warm; N=16; 256 GiB. This is not a pure locality toggle. |
| Mechanisms: setup reuse | zkInfer cold, zkInfer warm | Same policy and partitioning; matching condition-specific histories; N=1 and 8. |
| Scale-out | Whole-job, stage | Same-type nodes at 1/2/4/8/10; N=1 and a fixed N=16 batch. |
| Partitioning: decomposition | Monolithic, partitioned sequential | Same host and backend; cold/warm; old matched pairs retained with qualification. |
| Partitioning: granularity | zkInfer at g=1/2/4/8 plus isolated profiles | Same node configuration and runtime policy; separate histories per partitioning. |
| Overheads | zkInfer | N=1 and 16; instrument component work and coordinator resources. |
| Robustness: no history | zkInfer reference profiles / empty profiles | Warm artifacts in both; clear both coordinator and node histories. |
| Robustness: estimation error (optional) | zkInfer 0.9x / 1x / 1.1x initial estimates | Requires controlled perturbation and logging of effective estimates. |
| Robustness: failure (optional) | zkInfer no failure / one worker failure | Same batch and cluster; explicit failure trigger and restart behavior. |

Do not run every baseline for every experiment. The first subsection tests the
overall comparison; subsequent experiments change one mechanism or configuration
at a time. The coordinator-policy comparison changes several related decisions
and therefore must not be described as an isolated locality ablation.
