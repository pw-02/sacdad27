> Editable manuscript draft. Methods describe the proposed protocol; new measurements have not been run for this draft. Pending findings and editorial notes are marked. Earlier results retain their original configuration and are not current-runtime measurements. Figure/table numbering here is illustrative; LaTeX resolves numbering automatically.

# Evaluation

We evaluate whether zkInfer improves the completion time and throughput of partitioned inference proofs when requests share prover resources. We first measure end-to-end serving performance, then examine the contributions of memory admission, scheduling, and setup reuse. We next evaluate scaling across prover nodes and sensitivity to partition granularity. Finally, we measure operational overheads and examine behavior when resource profiles or worker availability change.

## Experimental Setup

#### Platforms.

We use a server with two AMD EPYC 9354 processors, providing 64 physical cores and 128 hardware threads, and 755 GiB of reported RAM for the controlled single-node experiments. Keeping the hardware fixed allows us to vary the memory available to proof execution without changing CPU capacity. The default usable proof-memory budget is 256 GiB; Section Contribution of Resource-Management Mechanisms also examines budgets of 64 and 128 GiB. We implement a budget by reserving the difference between the node’s reported physical memory and the selected budget. These are admission-accounting budgets, rather than measurements on machines whose physical memory equals the budget. All compared configurations use the same budget and background-resource allowance.

For distributed experiments, we use **\[PENDING: confirm worker instance type, per-node cores and reported RAM, network, storage, and coordinator placement\]**. We vary the cluster size over 1, 2, 4, 8, and 10 nodes, holding each node’s configuration fixed. Each node runs one worker manager and may execute multiple prover subprocesses. A prover subprocess is therefore distinct from a physical worker node and from the threads used internally by the proving backend.

*Draft note: Retain the old cloud deployment if it is still the intended platform: up to ten m6a.4xlarge instances, reported as 16 vCPUs and 64 GB per instance, with the coordinator on one worker. The old monolithic comparison instead used an r6a.32xlarge, reported as 128 vCPUs and 1 TB RAM. Do not silently label those measurements as results from the EPYC characterization server.*

#### Workloads and implementation.

The primary workloads are MNIST GAN, MobileNetV2, and NanoGPT (4L), representing generative, convolutional, and transformer computations. The current partitioning configuration produces 12, 100, and 181 proof jobs per request, respectively. Unless otherwise stated, each meaningful model operator forms one partition; Section Impact of Partition Granularity varies this choice. All configurations use the same model inputs, circuit-defining settings, and EZKL/Halo2 backend within each comparison. We keep prover thread settings fixed as job concurrency changes. The evaluated software configuration is **\[PENDING: zkInfer commit, EZKL/custom wheel version, OS/kernel, thread-pool settings, and storage medium\]**.

#### Comparison configurations.

*Monolithic* proves the full model in one backend invocation. *Partitioned sequential* executes the partitioned jobs one at a time on the same machine. Their comparison isolates decomposition without adding parallel workers. For concurrent serving, we compare three configurations using identical partitions. *Fixed-$k$* permits at most $k$ simultaneous jobs per node and disables stage admission. *Whole-job admission* reserves each job’s predicted peak memory before its prover pipeline starts and retains that reservation until the pipeline and output publication finish. *zkInfer* admits work at the backend’s controllable stage boundaries using predicted stage peaks. Whole-job and stage admission have no additional job-count cap in these experiments.

The concurrent admission comparisons share the same request-aware coordinator policy, artifact-reuse configuration, memory reserve, and profiling history. Fixed-$k$ retains the runtime’s ordinary node-resource checks; it is not a memory-unaware scheduler. We sweep $k\in\{1,2,4,8\}$. Where a figure shows a single fixed-concurrency baseline, we select $k$ using an independent eight-request pilot for each workload and setup condition, then hold it fixed throughout the reported load sweep. The complete fixed-$k$ sweep is retained in the supplementary results. Selection uses successful batch completion time; configurations with failed requests are not selected as the best-performing baseline.

#### Setup artifacts and resource profiles.

We distinguish *cold* execution, which regenerates circuit-specific setup artifacts, from *warm* execution, which loads matching artifacts generated before the measured run. SRS files are available in both conditions. Warmth describes artifact availability, not operating-system page-cache state or persistent in-memory prover objects. For local admission comparisons, artifacts are available on the same local filesystem under equivalent initial cache conditions. Distributed runs use **\[PENDING: artifact placement and storage backend\]**; that placement is held fixed across admission policies.

Resource profiles are collected before the evaluation from separate executions under the corresponding setup condition. Every policy starts from equivalent copies of both coordinator profiles and node-local stage histories. Cold execution can therefore use prior cold-run measurements without reusing compiled circuits or proving keys. Profiles may update during a trial, but no policy inherits another policy’s measured-run history. Whole-job admission uses the maximum historical stage estimate, retaining a larger coordinator job-peak estimate when available. Stage admission uses the estimate for the stage being entered. Both apply the same historical estimation rule and fixed memory reserve.

#### Traffic and measurements.

We use both request bursts and scheduled arrivals. Burst experiments submit $N\in\{1,4,8,16\}$ requests without waiting for earlier requests to finish. We record the actual submission spread rather than assuming perfectly simultaneous arrival. Sustained-load experiments use seeded Poisson arrivals, with identical model sequences and scheduled arrival times across policies. In addition to individual-model workloads, we evaluate a synthetic mixture that selects each of the three models with equal probability per request. This mixture balances request counts in expectation, not proving work.

Request latency is measured from the start of the submission RPC until the client observes request completion. It includes request preparation, queueing, artifact handling, proving, and finalization. We also retain latency from scheduled arrival and submission lag, so client-side injection delays remain visible. Completion polling uses the same interval across policies. Batch makespan is the time from the first submission to the final successful completion; a batch with failed or unresolved requests is reported as incomplete. Throughput counts successful request completions over an explicitly stated measurement interval. We distinguish the arrival-window completion rate from the rate including the final drain period. Client-side verification time is reported separately; **\[PENDING: confirm whether coordinator verification is enabled inside the request-completion boundary for the final runs\]**.

Each configuration is repeated three times, with policy order randomized across trials and arrival seeds paired within a trial. We report the mean and range of trial-level statistics, together with failed and timed-out request counts. Small bursts are summarized by median and maximum request latency rather than an unstable tail percentile. CPU utilization, actual memory use, admission waiting, and setup hits are recorded to explain performance. Unlike the motivation’s trace-driven simulation, these measurements include interference between concurrent prover processes.

## End-to-End Performance Under Concurrent Requests

#### Request bursts.

We compare Fixed-$k$, whole-job admission, and zkInfer on the same single-node platform with a 256 GiB proof-memory budget. Figure 1 shows warm request latency as the number of simultaneously active requests increases. All three configurations can execute several proof jobs concurrently; whole-job admission is therefore a concurrent resource-accounting baseline, rather than sequential execution. Cold runs repeat the comparison using cold profiles and regenerating setup for every job.

**Figure layout:** Three panels: MNIST GAN, MobileNetV2, NanoGPT. Horizontal axis: submitted requests (1, 4, 8, 16). Vertical axis: median request latency (minutes). Curves: selected Fixed-$k$, Whole-job, zkInfer. Warm setup; 256 GiB budget.

*Caption: Warm request latency under burst arrivals. Each point is the mean of the per-trial median request latencies; error bars show the trial range. The fixed-concurrency limit is selected in a separate pilot and then held fixed. Failed or incomplete batches are marked explicitly.*

We examine request latency alongside batch makespan because a policy may complete the overall batch sooner while delaying individual requests. We also inspect per-request completion distributions for the largest burst, including the mixed-model workload. These distributions reveal whether an aggregate benefit is concentrated in short requests or comes at the expense of a particular model. **\[PENDING: State the latency and makespan changes against each baseline, the conditions where gains are small or negative, and all failures. Explain any differences between cold and warm behavior using measured stage overlap.\]**

#### Sustained arrivals.

We next vary the offered request rate while holding hardware and memory budget fixed. An independent whole-job-admission pilot supplies a reference completion rate for each workload and setup condition. We test rates of 0.25, 0.5, 0.75, 1.0, and 1.25 times that reference, using the same absolute rates for every policy. Each trial schedules 64 requests and continues through the drain period or the declared timeout. We inspect backlog over the arrival interval; a high drain-inclusive completion rate alone does not establish sustainable service.

**Figure layout:** Two rows by three workloads. Horizontal axis: offered requests/hour. Top: arrival-window completion rate (requests/hour). Bottom: median request latency (minutes). Same three policy curves in every panel; warm setup.

*Caption: Serving performance as offered load increases. Policies receive the same scheduled requests at the same absolute rates. Completion rate is measured over the arrival interval; latency includes queueing. Backlog growth, failures, and submission lag are retained when interpreting the saturation point.*

Figure 2 relates the completion rate to the latency paid by individual requests. We repeat the experiment for the equal-probability model mixture and report per-model latency as well as the aggregate rate. **\[PENDING: Identify the load range in which each configuration keeps pace with arrivals, whether zkInfer changes that range, and whether the generator achieves the intended arrival schedule. Do not claim a steady-state capacity if backlog continues to grow or the observation interval is insufficient.\]**

## Contribution of Resource-Management Mechanisms

#### Memory reservation granularity.

To isolate admission, we compare whole-job and stage reservations while retaining the same coordinator policy, artifact state, and profile history. We repeat the eight- and sixteen-request experiments under 64, 128, and 256 GiB budgets. Figure 3 reports the sixteen-request results. Each selected budget must accommodate the largest eligible job; an infeasible configuration is marked as such rather than treated as a completed run.

**Figure layout:** Two rows (cold, warm) by three workloads. Horizontal axis: usable memory budget (64, 128, 256 GiB). Vertical axis: batch makespan (minutes). Two curves: Whole-job and zkInfer. Sixteen requests per trial.

*Caption: Effect of memory budget and reservation granularity on batch makespan. CPU capacity and coordinator policy remain fixed. Cold and warm executions use separate, matching histories. Error bars show the range across repeated trials.*

We compare the timing results with actual memory consumption and admission waits. A representative execution trace shows which stages overlap and whether the node remains memory-limited or instead reaches a CPU or storage bottleneck. Whole-job reservations cover the prover pipeline and output publication; supervisor-side artifact materialization precedes that reservation in the current implementation. The same boundary is used in every whole-job run. Keeping the selection policy fixed does not imply identical job order, since admission can change when jobs become runnable. **\[PENDING: Quantify improvements or regressions, peak actual memory, failures, and the cold/warm difference. Relate measured overlap to the motivation’s packing opportunity without equating simulated makespan with real performance.\]**

#### Coordinator scheduling.

We then keep stage admission enabled and compare request-fair FIFO, longest predicted job first within the selected request (LPT), and zkInfer’s resource-aware coordinator policy. FIFO and LPT use the same current-free-memory feasibility check, so their comparison isolates within-request ordering more directly. The resource-aware policy additionally changes feasibility checking and uses cached setup and predicted duration as placement preferences. Its comparison is therefore a coordinator-policy ablation, not an isolated test of cache locality or LPT. Request fairness remains enabled in all three policies.

| Model       | Policy  | Median (min) | Maximum (min) | Failed requests |
|:------------|:--------|-------------:|--------------:|----------------:|
| MNIST GAN   | FIFO    |            – |             – |               – |
|             | LPT     |            – |             – |               – |
|             | zkInfer |            – |             – |               – |
| MobileNetV2 | FIFO    |            – |             – |               – |
|             | LPT     |            – |             – |               – |
|             | zkInfer |            – |             – |               – |
| NanoGPT     | FIFO    |            – |             – |               – |
|             | LPT     |            – |             – |               – |
|             | zkInfer |            – |             – |               – |

*Caption: Coordinator-policy ablation with stage admission, warm setup, 16 requests, and a 256 GiB budget. Latency columns report means of per-trial statistics; failed requests are counted across trials. Dashes are pending.*

Table 1 reports the resulting request latencies. For the mixed workload, we additionally normalize each request’s latency by its model’s isolated latency under the same setup condition. This avoids treating a naturally longer model as unfairly delayed solely because its absolute latency is larger. **\[PENDING: Explain which scheduling choices affect request completion and whether the benefit is consistent across models; report per-model slowdown for the mixture. A pure locality or fairness-off claim needs a separate toggle.\]**

#### Setup reuse.

The characterization established the aggregate setup time and storage associated with reusable artifacts. Here we measure the effect on complete requests, including queueing and concurrent execution. We compare cold and warm zkInfer runs for one and eight requests, holding partitioning, hardware, admission, and coordinator policy fixed. Each condition uses matching historical profiles. Cold runs regenerate setup; warm runs load matching artifacts from local files.

|              |                   |      |                      |      |
|:-------------|------------------:|-----:|---------------------:|-----:|
|              | One request (min) |      | Eight requests (min) |      |
| Model        |              Cold | Warm |                 Cold | Warm |
| MNIST GAN    |                 – |    – |                    – |    – |
| MobileNetV2  |                 – |    – |                    – |    – |
| NanoGPT (4L) |                 – |    – |                    – |    – |

*Caption: Effect of setup reuse on completion time. One-request columns report request latency; eight-request columns report batch makespan. Entries are trial means; dashes mark pending measurements.*

Table 2 connects avoided setup work to request-level benefit. Warm execution also changes which stages consume time and memory, so its effect on concurrency need not equal the reduction in summed setup time. We interpret the completion-time results together with setup-hit counts and measured loading costs. **\[PENDING: Report the observed latency/makespan reductions and explain any departure from the aggregate setup-time savings. Do not interpret these local-reuse measurements as a quantified remote-retrieval or locality benefit.\]**

## Scaling Across Prover Nodes

We evaluate single-request and concurrent-request scaling separately. The first experiment holds one request fixed while increasing the node count. The second holds a sixteen-request batch fixed across cluster sizes. Both compare whole-job admission with zkInfer, using identical per-node resources and initial artifact placement. The single-node reference in each speedup calculation uses the same node type, partitioning, and policy as the corresponding distributed run.

**Figure layout:** Two rows by three workloads. Horizontal axis: physical prover nodes (1, 2, 4, 8, 10). Top: one-request latency (minutes). Bottom: sixteen-request makespan (minutes). Curves: Whole-job and zkInfer; warm setup.

*Caption: Single-request and concurrent-request scale-out on homogeneous nodes. Each row holds the amount of submitted work fixed as nodes are added. The coordinator placement and per-node memory budget are unchanged.*

Figure 4 distinguishes acceleration of one inference request from the ability to serve several requests concurrently. A long individual job can limit the former even when additional requests provide useful work for other nodes. We report allocated node-time alongside latency, computed as node count times the measured completion interval, to expose the resource cost of reducing completion time. This is allocated capacity, not measured CPU time. **\[PENDING: Insert absolute latency, speedup against the matched one-node configuration, and node-time. Explain straggler, CPU, and artifact-transfer limits using observed traces; do not infer them solely from curve shape.\]**

*Draft note: The old distributed curves can support a separately labelled legacy single-request result. Do not use the old 1,108 s high-memory-node NanoGPT result as the denominator for new m6a-node strong scaling without reconciling hardware.*

## Impact of Partition Granularity

#### Monolithic and partitioned execution.

We compare monolithic proving with partitioned sequential execution on the same machine. Both configurations process one request at a time and use the same backend thread settings. We measure cold and warm request latency, peak process memory, and the total size of reusable proving keys. Because the partitioned jobs execute sequentially, differences do not arise from additional prover processes or distributed compute capacity.

|               |                  |            |                  |            |
|:--------------|-----------------:|-----------:|-----------------:|-----------:|
|               | Cold latency (s) |            | Warm latency (s) |            |
| Model         |            Mono. | Part. seq. |            Mono. | Part. seq. |
| MNIST GAN     |            2,352 |      1,852 |              808 |        456 |
| MobileNetV2   |           25,652 |     16,050 |           11,231 |      9,639 |
| NanoGPT (4L)  |            8,527 |      2,520 |            6,165 |      1,108 |
| NanoGPT (10L) |              OOM |      8,066 |              OOM |      2,683 |
| TinyBERT      |            4,539 |      2,700 |            2,194 |      1,022 |

*Caption: Legacy single-worker results from the earlier implementation on an r6a.32xlarge instance. Partitioned jobs execute sequentially. These measurements use the old model/partition configurations and are separate from the current concurrent-serving experiments. OOM denotes failure from insufficient memory.*

The earlier single-worker measurements in Table 3 show that decomposition can reduce latency even before parallel execution. For example, warm NanoGPT (4L) latency decreases from 6,165 to 1,108 seconds, approximately $5.6\times$, while MobileNetV2 decreases from 11,231 to 9,639 seconds, approximately $1.2\times$. The larger NanoGPT configuration completes under partitioned execution whereas the monolithic configuration runs out of memory. These results describe the earlier implementation and are retained as evidence about decomposition; they are not measurements of the current stage-admission policy.

*Draft note: The old workload table reports 98 MobileNetV2 and 192 NanoGPT (4L) partitions, compared with 100 and 181 in the current characterization. Either retain this legacy qualification or replace the table with matched reruns. The old table’s memory units are reported inconsistently with the newer GiB convention; this latency-only table avoids silently converting those values.*

This experiment establishes the execution benefit of changing circuit granularity. It does not establish a benefit from stage admission or coordinator scheduling. The preceding resource-management comparisons therefore keep partitions fixed. To account for the cost of producing several proofs instead of one, we additionally measure their total size and the time required to verify all job proofs and their boundary consistency. **\[PENDING: Insert current peak-memory, proof-size, and verification results; identify any model that cannot complete monolithic proving without assigning a finite speedup to an OOM result.\]**

#### Sensitivity to partition size.

We vary the number of meaningful operators assigned to each partition over $g\in\{1,2,4,8\}$ while keeping the model, backend settings, and worker resources fixed. For each configuration, isolated sequential runs measure aggregate prover time, the longest job duration, and maximum per-job memory. A separate run using the same fixed worker configuration measures request latency under zkInfer. Profiles and setup artifacts are collected separately for each granularity; they are not transferred between different circuits.

**Figure layout:** Two rows by three workloads. Horizontal axis: operators per partition (1, 2, 4, 8). Top: aggregate isolated prover time and concurrent request latency (minutes). Bottom: maximum per-job memory (GiB). Fixed node configuration; warm setup.

*Caption: Sensitivity to partition granularity. Aggregate time is the sum of isolated job durations; request latency is measured under a fixed concurrent execution configuration. Peak memory is the largest isolated job footprint.*

This experiment examines both the work introduced by a partitioning choice and the parallelism it exposes. Lower aggregate time does not necessarily imply lower distributed latency: the longest job, per-job memory, and boundary overhead can also constrain execution. We report total proof bytes and verification time when comparing configurations with different numbers of proofs. **\[PENDING: State whether the default granularity remains effective under the actual runtime and where coarser partitions help or hurt. Restrict claims to the evaluated models/configurations rather than claiming operator-level splitting is universally optimal.\]**

*Draft note: Move the old motivation’s grouping-policy comparison here or to the appendix. Its profile-guided grouping results are useful evidence that summed operator costs need not predict grouped proving cost; they are not a new partitioning policy implemented by the current evaluation runner.*

## Operational Overheads and Robustness

#### Runtime overhead.

We measure the work required to prepare and coordinate proof jobs in addition to proving. Instrumentation records request preparation, coordinator decisions, artifact handling, admission checks, output publication, and verification. Time spent executing an admission check is distinguished from time spent waiting for sufficient memory: the latter reflects resource contention rather than the computational cost of the mechanism.

Table 4 compares one request with a sixteen-request batch under warm setup. We also record coordinator CPU time and peak memory. Component activities can overlap, so accumulated component times are not added together and presented as request latency. Verification uses the measurement boundary defined in Section Experimental Setup.

| Component          | Statistic          | $N=1$ | $N=16$ |
|:-------------------|:-------------------|------:|-------:|
| Preparation        | Median s/request   |     – |      – |
| Scheduling         | Median ms/decision |     – |      – |
| Admission check    | Median ms/check    |     – |      – |
| Artifact handling  | Median s/job       |     – |      – |
| Output publication | Median s/job       |     – |      – |
| Verification       | Median s/request   |     – |      – |
| Coordinator CPU    | CPU-s/request      |     – |      – |
| Coordinator memory | Peak MiB           |     – |      – |

*Caption: Runtime costs for **\[PENDING: workload\]** under warm setup. Entries are means of trial-level statistics over three trials. Component times exclude queueing and may overlap.*

**\[PENDING: Report overhead relative to request latency and its change with load. Provide per-model results in supporting material if the main table uses one model. Use critical-path measurements when attributing end-to-end latency.\]**

#### Resource-profile availability and error.

We compare zkInfer with reference profiles against execution with no prior profile history. Setup artifacts remain warm in both cases, separating profile availability from setup regeneration. Each repetition begins with the designated coordinator and node histories. We measure completion time, admission waits, peak actual memory, and failed requests for a sixteen-request batch.

A separate sensitivity experiment scales initial memory estimates to $0.9$, $1.0$, and $1.1$ times the reference estimates without changing the proof jobs. The factors define controlled perturbations, not a measured distribution of naturally occurring errors. We retain the configured online-update behavior and record how estimates evolve. Successful completion under these perturbations does not establish a guaranteed upper bound on memory demand.

*Draft note: No-profile runs require the runner’s explicit unprofiled mode and empty coordinator and node histories. Estimate perturbation needs a test harness that changes both estimator inputs consistently. Check the actual estimates used for admission, since an unchanged fallback may override a perturbed profile.*

#### Worker failure.

We compare a fixed request batch with a matched no-failure run, terminating one active worker at a predefined point after execution begins. Failure timing, worker selection, and restart behavior remain fixed across repetitions. We measure detection time, delay until affected work resumes, repeated proof work, additional batch completion time, and the final status of every request. Completed outputs are verified. Restarting the failed worker and completing the batch on surviving workers are treated as separate recovery conditions.

| Condition              | Makespan (min) | Peak memory (GiB) | Failed requests |
|:-----------------------|---------------:|------------------:|----------------:|
| Reference profiles     |              – |                 – |               – |
| No initial profiles    |              – |                 – |               – |
| Estimates $\times 0.9$ |              – |                 – |               – |
| Estimates $\times 1.1$ |              – |                 – |               – |
| One worker failure     |              – |                 – |               – |

*Caption: Robustness under **\[PENDING: workload, cluster size, and budget\]**, with 16 requests and warm setup. The reference row also provides the no-failure baseline. Incomplete batches are marked explicitly. Makespan is the trial mean; memory is the largest observed per-node footprint; failures are summed over trials.*

**\[PENDING: Report the effects of missing or inaccurate profiles and the observed recovery outcome. Specify the failure trigger and whether the worker restarts. Report unsupported recovery or incomplete requests directly.\]**

*Draft note: These are proposed experiments, not claims that recovery or estimate perturbation has been implemented or validated. Omit worker failure if recovery is outside the paper’s scope. If no robustness experiment is run, rename this subsection *Operational Overheads* and retain only the overhead analysis.*
