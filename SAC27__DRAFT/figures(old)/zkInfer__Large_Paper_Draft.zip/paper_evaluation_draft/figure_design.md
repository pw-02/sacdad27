# Figure and table specifications

These designs contain no dummy measurements. Matching figure slots and captions
are already in evaluation.tex. Export vector PDFs using actual paper dimensions
(roughly 3.3-inch single column and 7-inch double column), with 8-9 pt final-size
labels, embedded fonts, and no title above the plot. Use thin horizontal grids,
no top/right spines, and no dual axes. Whole-job: gray squares/dashed; zkInfer:
blue circles/solid; selected Fixed-k: orange triangles/dotted. Shapes and line
styles must distinguish curves in grayscale.

Points summarize independent trials, with ranges for three trials. Do not call
ranges confidence intervals or count requests from one trial as independent
replications. Mark failures/infeasible cases; never plot missing results at zero.

## T1: Decomposition (single column)

Rows: models. Columns: cold monolithic/partitioned sequential and warm monolithic/
partitioned sequential, all seconds. Included legacy table has actual old values.
Replace matched pairs together; never combine an old monolithic denominator with
a new partitioned numerator. Keep constraints/key storage out of this compact table.

## F1: Burst request latency

`figures/evaluation/burst_latency.pdf`: one row by three workloads, double column,
approximately 2.1 inches high. x=requests 1,4,8,16; y=median request latency in
minutes. Curves: selected Fixed-k, Whole-job, zkInfer. Warm, 256 GiB usable budget.
Each point is the mean of trial medians; error bars span trial medians.

Select k from 1/2/4/8 in an independent eight-request pilot for each model/setup,
then hold it fixed across reported load. Show the complete sweep in the appendix.
Do not retrospectively select a different best k for each measured point.
Add batch makespan and largest-burst request-latency ECDFs in the appendix.

Required data: workload, setup, policy, selected_k, trial_id, seed, budget,
request count, request timestamps/status, median/max latency, makespan, failures.

## F2: Scheduled arrivals

`figures/evaluation/arrival_rate.pdf`: two rows by three workloads, double column,
approximately 3.4 inches high. x=offered requests/hour. Top y=arrival-window
completion rate (requests/hour); bottom y=median request latency (minutes).
Same three policy curves. A y=x reference appears only in throughput panels.

Use the same absolute rates across policies, derived from an independent whole-job
pilot: 0.25,0.5,0.75,1,1.25 times its reference rate. Schedule 64 requests per trial
and retain the drain interval. Inspect backlog and client submission lag before
identifying saturation. Finite-window rate is not automatically steady-state capacity.

IMPORTANT: traffic.py's summary reports drain-inclusive throughput. Compute
arrival-window completions from timestamps; do not relabel the summary statistic.
Keep failures and unresolved requests visible when reporting latency distributions.
The mixture gets a separate two-panel version plus per-model slowdown in appendix.

## F3: Memory-budget sensitivity

`figures/evaluation/memory_budget.pdf`: two rows (cold/warm), three workload
columns. x=64,128,256 GiB accounted budget; y=16-request makespan in minutes.
Only Whole-job and zkInfer curves. Use matched profiles for each setup condition.
CPU and physical hardware stay fixed. State host RAM H and reserve H-B; this is
not an emulation of CPU/bandwidth/storage on a smaller VM.

Supporting trace: two aligned policy panels, x=elapsed time, y=actual and reserved
memory in GiB, budget line. Add a small stage-activity strip below if needed.
Distinguish instantaneous sampled demand from reservation size.

## T2: Scheduling ablation (single column)

Nine rows: FIFO/LPT/zkInfer for each model. Columns: median latency, maximum
latency, failed request count. N=16, warm, 256 GiB, stage admission throughout.
Use means of per-trial latency statistics and summed failure counts.
FIFO/LPT share a fit predicate; resource_aware changes it and adds cache/duration
preferences. This is a coordinator-policy ablation, not a pure locality test.

## F4: Distributed scale-out

`figures/evaluation/scale_out.pdf`: two rows by three workloads. x=physical nodes
1,2,4,8,10. Top y=one-request latency; bottom y=fixed sixteen-request makespan,
both minutes. Whole-job and zkInfer, warm. Keep node type and per-node budget fixed.
Optional endpoint speedup annotations use that policy's same-type one-node point.
Node-time (nodes times elapsed) goes in prose or appendix, not another y axis.
Do not combine an old r6a baseline with m6a endpoints as homogeneous strong scaling.

## F5: Partition sensitivity (main or appendix)

`figures/evaluation/partition_granularity.pdf`: two rows by workload. x=operators
per partition 1,2,4,8. Top y=aggregate isolated prover time AND concurrently measured
request latency, both minutes, clearly labelled as different metrics. Bottom
y=maximum isolated job memory in GiB. Fix hardware and setup condition.
Profile every circuit configuration independently. Add longest job duration and
proof/verification overhead in a supporting table if useful.
The old isolated measurements cannot fill the concurrent-latency curve.

## T3: Request-level reuse (single column)

Rows=model. Columns grouped as one request (cold/warm) and eight requests
(cold/warm). First group is request latency; second is batch makespan. Both minutes.
Caption must distinguish them. Do not repeat motivation's aggregate setup/key-size
table here. This experiment belongs within Contribution of Resource-Management Mechanisms.

## T4: Operational overhead (single column; select rows after measurement)

Rows: preparation, scheduling, admission-check execution, artifact handling,
publication, verification, coordinator CPU time, and coordinator peak memory.
Columns: component, statistic with units, one request, sixteen requests.
Specify the workload in the caption; retain other models in supporting results.
Use means of per-trial statistics. Admission waiting is a separate contention
metric, not admission-check computational overhead. Do not sum overlapping times
to claim a fraction of end-to-end latency.

## T5: Robustness (optional single column)

Rows: reference profiles, no initial profiles, 0.9x estimates, 1.1x estimates,
and one worker failure. Columns: makespan, maximum observed per-node memory,
failed requests. Use the same workload, cluster, budget, and setup state in all
rows; reference profiles provide the no-failure baseline. State the failure
trigger, worker-selection rule and whether the worker restarts. Record recovery
delay and repeated work in text or supporting results. These are proposed tests;
the estimate-perturbation and failure-injection harnesses are not supplied here.

## Appendix priorities

1. Full fixed-k sweep and chosen k values.
2. Burst makespan, completion distributions and cold counterparts of F1.
3. Mixed workload throughput plus per-model slowdown.
4. Actual/reserved-memory trace explaining overlap or lack of benefit.
5. Detailed old grouping-policy table and proof/verification overhead.
6. Recovery or second-backend measurements only if claimed contributions.

Every plot uses real observations when available. Until then, keep the labelled
LaTeX placeholder instead of a fabricated trend.
