# Old-to-new results mapping

Source: the uploaded socc26-paper457(1).pdf. These are old-draft measurements,
not independent reruns of the present implementation.

| Old material | Destination | Treatment |
| --- | --- | --- |
| Section 3/Table 1 partition granularity | Granularity sensitivity / appendix | Preserve old isolated data; add current concurrent latency separately |
| Section 3.3/Figure 3 heterogeneity | Motivation | Replace with newer three-workload characterization |
| Section 6.1/Table 2 setup/workloads | Experimental setup | Reconcile hardware, model settings and partition counts |
| Section 6.2/Table 3 sequential versus monolithic | Decomposition | Included as explicitly legacy table |
| Figure 5 key loading/proving and peak memory | Decomposition/reuse supporting detail | Keep if useful, check units and boundaries |
| Figures 6/7 single-node worker sweep | Fixed-k pilot context / appendix | Does not establish whole-job versus stage admission |
| Figure 8 distributed scaling | Scale-out | Check baseline node type before reusing speedups |
| Figure 9 zkTorch TinyBERT | Optional portability | Integration evidence, not cross-backend admission benefit |

## Absolute latency values carried into legacy_results.tex

Old Table 3, seconds, three-run averages according to old Section 6.1:

| Model | Mono cold | Part. sequential cold | Mono warm | Part. sequential warm |
| --- | ---: | ---: | ---: | ---: |
| MNIST GAN | 2352 | 1852 | 808 | 456 |
| MobileNetV2 | 25652 | 16050 | 11231 | 9639 |
| NanoGPT 4L | 8527 | 2520 | 6165 | 1108 |
| NanoGPT 10L | OOM | 8066 | OOM | 2683 |
| TinyBERT | 4539 | 2700 | 2194 | 1022 |

These used one r6a.32xlarge, reported as 128 vCPUs and 1 TB RAM.
The draft does not relabel that hardware as the current EPYC server.

## Other reusable findings

- Old warm process sweep, one to fifteen processes on one node: NanoGPT 1108 to
  399 s; MobileNetV2 9639 to 2384 s; TinyBERT 1022 to 333 s. These are not fifteen nodes.
- Old scale-out text: NanoGPT 1108 to 89 s, reported 12.7x MobileNetV2 and 10.5x
  TinyBERT speedups. Verify matching reference hardware; do not reconstruct missing
  curve points from rounded speedups.
- Old zkTorch TinyBERT: 16008 s standalone versus 4899 s with fifteen zkInfer workers
  on one r6a.32xlarge, about 3.3x. Retain with configuration, or rerun if backend changed.
- Old Table 1 excludes offline setup and used a dedicated dual-EPYC server reported
  as 768 GB. It is not full cold-request latency on the cloud platform.

## Resolve before reuse

1. Old MobileNetV2/NanoGPT4L partition counts are 98/192; current counts are 100/181.
   MNIST is 12 in both, but equal count does not prove identical circuits.
2. Match graph simplification, operator filtering, input shapes, model hashes and
   proving settings. Do not copy old precision/parameter counts by model name alone.
3. Old cloud hardware differs from the current characterization host. Use matched
   absolute measurements for each ratio.
4. Old memory units say GB; current reports use GiB. Do not relabel without checking
   source bytes/collection code. legacy_granularity.tex retains GB as reported.
5. Old latency excludes client verification; current coordinator verification is
   optional. State whether it lies inside the request completion interval.
6. Old headline and scale-out figure speedups are rounded differently. Recompute
   ratios from raw matched runs, not the introduction's maximum claim.
7. New setup/key-size measurements differ from old ones; keep their provenance.

## Measurements the old paper cannot supply

Actual whole-job versus stage admission, warm-stage benefit under concurrency,
scheduled-arrival throughput/queue growth, equal-condition scheduling ablations,
mixed-request slowdown, isolated locality benefit, or thread-allocation benefit.
The motivation simulation remains an opportunity estimate, not runtime evidence.
