# zkInfer SoCC Positioning Revision

## Core positioning

The revised manuscript changes the central story from:

> zkML proving is expensive, and distributed execution can accelerate it.

To:

> zkML proof generation is an emerging cloud serving workload whose monolithic execution model concentrates latency and memory on one machine, limits resource management, and prevents a single request from scaling across cloud capacity. zkInfer converts that workload into fine-grained, profiled, resource-managed jobs.

The technical system, measurements, and reported numerical results were preserved. The revision does not invent new experiments or claim results that are not present in the current evaluation.

## Major edits

### Title and front matter

- New title: **zkInfer: A Cloud Proof-Serving System for Scalable Verifiable ML Inference**
- Added active CCS concepts and SoCC-oriented keywords.
- Updated the commented conference metadata from Middleware to SoCC.

### Abstract

- Opens with cloud ML serving rather than generic outsourced inference.
- Frames monolithic proof generation as a poor cloud execution abstraction.
- Presents zkInfer as a cloud proof-serving system and resource-management layer.
- Preserves the existing headline results: 5.6x single-worker latency reduction, 69x distributed latency reduction, and 48x peak-memory reduction.

### Introduction

- Makes the cloud systems problem explicit before introducing zkInfer.
- Separates cryptographic optimizations from the execution-layer problem.
- Establishes the full-model proof as the problematic unit of cloud execution.
- Recasts decomposition as a mechanism for exposing schedulable work, reducing host memory requirements, and enabling horizontal scaling.
- Rewrites the contributions around workload characterization, cloud proof serving, resource-aware orchestration, and cloud deployment results.

### Background and characterization

- Renames the bottleneck section to **Proof Generation as a Cloud Serving Bottleneck**.
- Reframes the splitting study as a study of proof-serving execution granularity.
- Interprets maximum job time and peak per-job memory as scheduling and host-capacity signals.
- Strengthens the transition from workload characterization to the need for a proof-serving runtime.
- Removes a stray `Required packages:` line and fixes an existing typo in the characterization text.

### Design and implementation

- Renames the design section to **zkInfer: A Cloud Proof-Serving System**.
- Describes the architecture as a proof-serving control plane plus a distributed execution layer.
- Elevates job profiling, artifact reuse, phase-aware memory admission, and worker-pool scaling as first-class cloud systems mechanisms.
- Renames the scheduling section to **Resource-Aware Proof-Serving Scheduler**.
- Preserves the existing correctness, fault tolerance, and proof-composition mechanisms.

### Evaluation

- Adds explicit evaluation questions centered on cloud serving and resource management.
- Defines end-to-end serving latency, peak host memory, and artifact footprint as the primary system metrics already supported by the current experiments.
- Reframes the single-worker study around converting monolithic proving into resource-manageable jobs.
- Reframes scaling as adding cloud worker capacity within one host and across nodes.
- Reframes the second backend as execution-layer portability and GPU acceleration as a complementary backend optimization.

### Related work and conclusion

- Promotes Related Work to a full section.
- Leads with ML serving and cloud resource management.
- Positions zkInfer relative to both ML serving systems and distributed proving systems.
- Rewrites the conclusion around the unusual resource profile of cloud proof serving and the need for an execution layer around the prover.

## High-priority evaluation gaps for SoCC reviewers

These are not wording issues; they require additional measurements. The current revision deliberately does not claim these results.

1. **Concurrent-request serving behavior**
   - Vary concurrent requests (for example 1, 2, 4, 8, 16).
   - Report completed proofs/hour and p50/p95 end-to-end latency.
   - Include mixed-model workloads if feasible.

2. **Scheduler ablation**
   - Compare FIFO, longest-processing-time-first, memory-aware admission, and the full policy.
   - Report request latency, throughput, peak host memory, and OOM/failed placements.

3. **Cloud cost and aggregate resource use**
   - Report dollar cost per completed proof or a latency-cost Pareto curve.
   - Report both peak memory per host and aggregate cluster resource consumption to show that the system is not only replacing one large machine with many inefficient smaller machines.

4. **Artifact-cache sensitivity**
   - Evaluate hit rate and request latency as cache capacity changes.
   - Consider artifact locality or data transferred from object storage.

5. **Scaling efficiency and saturation**
   - Report speedup/N workers and explain critical-path, CPU, memory, I/O, or artifact-loading limits.

## Claim-discipline notes

- The scheduler is described as supporting concurrent requests, but the current evaluation does not quantify multi-tenant throughput, tail latency, or fairness. Avoid language claiming that the scheduler *improves* these metrics until an ablation/load experiment is added.
- The current evaluation strongly supports single-request latency reduction, host-memory reduction, feasibility of a larger model, horizontal scaling, backend portability, and complementarity with GPU acceleration.
- The cloud framing is strongest when the paper emphasizes the execution unit, host memory constraints, artifact reuse, and horizontal scaling rather than merely adding the word “cloud.”

## Submission checks

- The compiled revised manuscript is currently **14 pages total**, and the conclusion extends onto page 14 before the references. SoCC full research papers allow **12 pages plus unlimited references**, so a separate page-budget pass is still needed.
- The current source compiles without undefined citations or cross-references.
- The ACM class reports accessibility warnings for several figures that lack `\\Description{}` text. These are warnings rather than compile errors, but adding descriptions would improve accessibility compliance.
- The SoCC 2026 CFP states that generative-AI use to create manuscript content must be disclosed. Because this revision used ChatGPT for wording and positioning, add an appropriate disclosure in the manuscript or confirm the expected anonymous-review wording with the chairs. A possible disclosure is:

  > ChatGPT was used to assist with revising manuscript wording and narrative positioning. The authors reviewed, edited, and take responsibility for all resulting content.
