# SoCC positioning summary

**One-sentence thesis**

zkInfer transforms monolithic zkML proof generation into a scalable, resource-managed cloud serving workload.

**Problem**

Monolithic proof generation couples each verifiable-inference request to the latency and memory footprint of the full encoded model, prevents a request from using additional cloud nodes, and provides no fine-grained units for resource-aware placement or artifact reuse.

**Insight**

The full model is not necessarily the right cloud execution unit. Decomposing the inference graph into smaller proving jobs can reduce the resource demand of individual invocations, expose parallel work, and create schedulable units with reusable artifacts.

**System**

zkInfer provides the cloud systems layer around existing zkML backends: request orchestration, self-contained proving jobs, job-level cost profiles, phase-aware memory admission, artifact caching, fault recovery, and distributed worker execution.

**Evidence currently in the paper**

- Up to 5.6x lower warm end-to-end latency with one worker.
- Up to 69x lower distributed end-to-end latency relative to monolithic EZKL.
- Up to 48x lower peak per-machine memory.
- Completion of a larger transformer workload that the monolithic baseline cannot fit in memory.
- Portability to a second zkML backend.
- Compatibility with GPU acceleration of the underlying prover.

**Avoid overclaiming**

Until additional experiments are added, do not claim measured improvements in multi-tenant throughput, p95/p99 latency, fairness, scheduler quality, or cloud cost.
